# Code Challenges

Above is a list of 4 code challenges.

PSN: Create your 'Porn Star Name'
Basic: Shopping Calculator - keep track of your money
Hard: Chinese Horoscope Calculator
ATM: self evident...

They use node and a module called [prompt](https://www.npmjs.com/package/prompt). Do them in order: psn, Basic, Hard (optional). Homework is the ATM. Instructions are in the README.md files in each directory

To use each one, use your console to navigate into the file and then do `npm install`

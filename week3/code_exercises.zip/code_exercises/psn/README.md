# Porn Star Name Generator

Your porn star name (U.K. version) is the name of your first pet followed by your mother's maiden name.

Use prompt to ask the user for both, then give them their completed name...

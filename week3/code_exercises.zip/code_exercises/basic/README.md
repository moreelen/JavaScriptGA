# Shopping Calculator

## Task:
1. Create a program that prompts to enter the cost each time they put something in the basket
2. After the user inputs and presses return, have the program display the running total
3. For extra points prompt the user first for a budget total, then on each addition to the basket show the running total AND the remaining budget
